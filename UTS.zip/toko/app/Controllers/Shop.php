<?php

namespace App\Controllers;

class Shop extends BaseController
{ 
    protected $session;
    public function __construct()
	{ 
        helper('form'); 
		$this->session = session();
	}

	public function index()
	{
		$barangModel = new \App\Models\BarangModel();
        $kategoriModel = new \App\Models\KategoriModel();
		$barang = $barangModel->select('barang.*, kategori.nama AS kategori')->join('kategori', 'barang.id_kategori=kategori.id')->findAll();
        $kategori = $kategoriModel->findAll();
		return view('shop/index',[
			'barangs' => $barang,
            'kategoris' => $kategori,
		]);
	}

    public function category()
	{
		$id = $this->request->uri->getSegment(3);

		$barangModel = new \App\Models\BarangModel(); 
        $kategoriModel = new \App\Models\KategoriModel();
		$barang = $barangModel->select('barang.*, kategori.nama AS kategori')->where('id_kategori', $id)->join('kategori', 'barang.id_kategori=kategori.id')->where('id_kategori', $id)->findAll(); 
        $kategori = $kategoriModel->findAll();
		return view('shop/index',[
			'barangs' => $barang, 
            'kategoris' => $kategori,
		]);
	} 

    public function product()
	{
		$id = $this->request->uri->getSegment(3);

		$barangModel = new \App\Models\BarangModel(); 
        $kategoriModel = new \App\Models\KategoriModel();
        $komentarModel = new \App\Models\KomentarModel();
		$barang = $barangModel->find($id); 
        $kategori = $kategoriModel->findAll();
        $komentar = $komentarModel->select('komentar.*, user.username')->join('transaksi_detail', 'komentar.id_transaksi_detail=transaksi_detail.id')->join('transaksi','transaksi_detail.id_transaksi=transaksi.id')->join('user','transaksi.id_user=user.id')->where('id_barang', $id)->findAll();
  
		return view('shop/product',[
			'barang' => $barang, 
            'kategoris' => $kategori,
            'komentars' => $komentar,
		]);
	} 
}